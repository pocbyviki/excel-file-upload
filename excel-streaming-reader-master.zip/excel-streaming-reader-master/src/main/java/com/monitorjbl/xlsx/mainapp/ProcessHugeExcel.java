package com.monitorjbl.xlsx.mainapp;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.SystemOutLogger;

import com.monitorjbl.xlsx.StreamingReader;
import com.monitorjbl.xlsx.model.Bank;
import com.monitorjbl.xlsx.model.BankCopy;
import com.poiji.bind.Poiji;
import com.poiji.option.PoijiOptions;
import com.poiji.option.PoijiOptions.PoijiOptionsBuilder;

/**
 * FAQ- why we should not use System.out.println()?
 * ANS- By using sysout it write on console and it cause performance issue, slow down system. 
 * 		to see the impact uncomment printXlsToConsole() and run. see the time took, instead run mapXlsToModel() and see time taken
 * FAQ- How to map rows to dto?
 * ANS- either we can write switch case to set values or use poji mapper
 * 
 * @author test
 *
 */
public class ProcessHugeExcel {

	public static void main(String[] args)  {
		
		
		//printXlsToConsole();
		mapXlsToModel();
		//maptoModelUsingPoji();
		//mapXlsToModelUsingThread();
		
	
	}
	
	private static void mapXlsToModelUsingThread() {

		long st = new Date().getTime();
			try (
				  InputStream is = new FileInputStream(new File("C:/Users/test/Downloads/68774.xlsx"));
				  Workbook workbook = StreamingReader.builder()
				          							.rowCacheSize(10000)
				          							.bufferSize(4096)
				          							.open(is)
				) {
				System.out.println("WorkBook loaded in "+(new Date().getTime()-st)/1000+" sec.");
				long startTime = new Date().getTime();
				System.out.println("======================mapping to model started at:"+new Date()+"===========================");
				List<Bank> list = new ArrayList<>();
				  for (Sheet sheet : workbook){ // worksheet iteration
					  
					  startThread(sheet,list);
				    
				  }
				  System.out.println("======================mapping to model done at:"+new Date()+"===========================");
				  long total = new Date().getTime() - startTime;
				  long sec = total/1000;
				System.out.println("====================Total time took to process "+sec+" sec.");
				System.out.println("Size of list: "+list.size());
				//printBankList(list);
				
			} catch (IOException e) {
					
					e.printStackTrace();
				} 
		
	
		
	}
	
	private static void startThread(Sheet sheet, List<Bank> list) {
		new Thread(()-> {
			System.out.println(sheet.getSheetName());
		    int row =0;
		    for (Row r : sheet) { // worksheet's rows iteration
		    	row++;
		    	Bank bank = new Bank();
		      for (Cell c : r) { // reach row's cell iteration
		    	  if (row ==1) {
		    		 // printHeader(c, row);
		    	  } else {
		    		  mapCellValueToModel(bank,c);
		    		  if (c.getColumnIndex() == 7) {
		    			  list.add(bank); 
		    		  }
//		    		  System.out.print(c.getStringCellValue()+"   ");
		    		  
		    	  }
		        
		      }
		    }
		}).start();
	}

	/**
	 * this one is faster to map excel rows to model but
	 * it works with only one sheet
	 */
	private static void maptoModelUsingPoji() {
		
		List<BankCopy> employees = Poiji.fromExcel(new File("C:/Users/test/Downloads/68774.xlsx"), BankCopy.class);
		System.out.println(employees.size());
		for (BankCopy bankCopy : employees) {
			System.out.println(bankCopy);
		}
	}

	/**
	 * this method will map excel file row to Bank model.
	 */
	private static void mapXlsToModel() {
		long st = new Date().getTime();
			try (
				  InputStream is = new FileInputStream(new File("C:/Users/test/Downloads/68774.xlsx"));
				  Workbook workbook = StreamingReader.builder()
				          							.rowCacheSize(10000)
				          							.bufferSize(4096)
				          							.open(is)
				) {
				System.out.println("WorkBook loaded in "+(new Date().getTime()-st)/1000+" sec.");
				long startTime = new Date().getTime();
				System.out.println("======================mapping to model started at:"+new Date()+"===========================");
				List<Bank> list = new ArrayList<>();
				  for (Sheet sheet : workbook){ // worksheet iteration
				    System.out.println(sheet.getSheetName());
				    int row =0;
				    for (Row r : sheet) { // worksheet's rows iteration
				    	row++;
				    	Bank bank = new Bank();
				      for (Cell c : r) { // reach row's cell iteration
				    	  if (row ==1) {
				    		 // printHeader(c, row);
				    	  } else {
				    		  mapCellValueToModel(bank,c);
				    		  if (c.getColumnIndex() == 7) {
				    			  list.add(bank); 
				    		  }
//				    		  System.out.print(c.getStringCellValue()+"   ");
				    		  
				    	  }
				        
				      }
				    }
				  }
				  System.out.println("======================mapping to model done at:"+new Date()+"===========================");
				  long total = new Date().getTime() - startTime;
				  long sec = total/1000;
				System.out.println("====================Total time took to process "+sec+" sec.");
				System.out.println("Size of list: "+list.size());
				printBankList(list);
				
			} catch (IOException e) {
					
					e.printStackTrace();
				} 
		
	}

	private static void printBankList(List<Bank> list) {
		long ms = new Date().getTime();
		/*for (Bank bank : list) {
			System.out.println(bank);
		}*/
		//System.out.println("Total time taken to print list elements: "+(new Date().getTime()-ms)/1000+" sec.");
		//list.stream().forEach(System.out::println);
		//list.forEach(System.out::println);
		//list.forEach(bank -> System.out.println(bank));
		list.parallelStream().forEach(bank -> System.out.println(bank));
		System.out.println("Total time taken to print list elements: "+(new Date().getTime()-ms)/1000+" sec.");
		
	}

	private static void mapCellValueToModel(Bank bank, Cell c) {
		
		switch (c.getColumnIndex()) {
		case 0:
			bank.setBank(c.getStringCellValue());
			break;
		case 1:
			bank.setIfsc(c.getStringCellValue());
			break;
		case 2:
			bank.setBranch(c.getStringCellValue());
			break;
		case 3:
			bank.setAddress(c.getStringCellValue());
			break;
		case 4:
			bank.setContact(c.getStringCellValue());
			break;
		case 5:
			bank.setCity(c.getStringCellValue());
			break;
		case 6:
			bank.setDistrict(c.getStringCellValue());
			break;
		case 7:
			bank.setState(c.getStringCellValue());
			break;
		default:
			break;
		}
	}

	private static void printXlsToConsole() {
		try (
				  InputStream is = new FileInputStream(new File("C:/Users/test/Downloads/68774.xlsx"));
				  Workbook workbook = StreamingReader.builder()
				          							.rowCacheSize(10000)
				          							.bufferSize(4096)
				          							.open(is)
				) {
				long startTime = new Date().getTime();
				System.out.println("======================start at:"+new Date()+"===========================");
				  for (Sheet sheet : workbook){
				    System.out.println(sheet.getSheetName());
				    int row =0;
				    for (Row r : sheet) {
				    	row++;
				    	 System.out.println();
				      for (Cell c : r) {
				    	  if (row ==1) {
				    		  printHeader(c, row);
				    	  } else {
				    		  System.out.print(c.getStringCellValue()+"   ");
				    	  }
				        
				      }
				    }
				  }
				  System.out.println("======================End at:"+new Date()+"===========================");
				  long total = new Date().getTime() - startTime;
				  long sec = total/1000;
				System.out.println("====================Total time took to process "+sec);	
			} catch (IOException e) {
					
					e.printStackTrace();
				} 
		
	}

	private static void printHeader(Cell c, int row) {
		
		switch (c.getStringCellValue()) {
		case "BANK":
			System.out.print("                     "+c.getStringCellValue()+"                     ");
			break;
		case "IFSC":
			System.out.print("   "+c.getStringCellValue()+"    ");
			break;
		case "BRANCH":
			System.out.print("   "+c.getStringCellValue()+"    ");
			break;
		case "ADDRESS":
			System.out.print("                                   "+c.getStringCellValue()+"                                 ");
			break;
		case "CONTACT":
			System.out.print("  "+c.getStringCellValue()+"  ");
			break;
		case "CITY":
			System.out.print("    "+c.getStringCellValue()+"    ");
			break;
		case "DISTRICT":
			System.out.print("    "+c.getStringCellValue()+"     ");
			break;
		case "STATE":
			System.out.print("    "+c.getStringCellValue()+"     ");
			break;
		default:
			break;
		}
	
	}
	
	
}
