package com.monitorjbl.xlsx.impl;

interface Supplier {
    Object getContent();
}
